This virus is not a virus! (You must run on a real machine, otherwise there! Reboot to return to normal! You can use this to troll people)

Make sure to have net installed! https://dotnet.microsoft.com/download/dotnet/5.0/runtime/

Please only use on windows vista or later